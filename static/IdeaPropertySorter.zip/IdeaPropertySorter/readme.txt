This is a very first try to write a plugin in idea. It should work as advertised and features are added as they are needed.

Downloaded from http://maxheapsize.com/download

Thanks for trying, Oliver

