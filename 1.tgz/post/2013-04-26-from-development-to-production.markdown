--- 
layout: post
title: "Provisioning from Development to Production"
categories: production provisioning development deployment 
comments: true
---

My <a href="http://bed-con.org/2013/talks/">BedCon 2013</a> talk. Covering commiting code, packaging,testing, deployment and organisational changes.

<script async class="speakerdeck-embed" data-id="e8470d7082450130e5211231381a9963" data-ratio="1.33333333333333" src="//speakerdeck.com/assets/embed.js"></script>
