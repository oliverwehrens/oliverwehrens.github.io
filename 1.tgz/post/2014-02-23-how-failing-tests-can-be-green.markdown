+++
date = "2014-02-13"
title = "How failing tests can be green"
tags = ["green build", "deployment", "tests"]
aliases = [
  "/2014/02/23/how-failing-tests-can-be-green/"
]
+++

Imagine this conversation:

![red](/static/traffic-light-vector-icon.jpg)

_Friend_: "We have an integration system where we deploy every two weeks all commits and run hundreds of end to end tests on it."

_Me_: "And if everything passed it goes into production?"

_Friend_: "Yes."

_Me_: "How often do they fail?"

_Friend_: "Uhmm, well like every night. But we just take the failing tests and run them again and after that or the next run they will be green."

_Me_: "And then it goes into production?"

_Friend_: "Yes."

_Me_: "Uh?"

<!-- more -->

After some further digging it turns out the tests where not green in the first run for some time (like months). Nobody seem to care. Everybody thought they have just an unstable test system and no time for fixing it.

### "Slow is the new fast". ###

At some point somebody took the time to investigate one of the failing tests. He found that this was a real bug also happning in production and he opened a bug ticket for it. Yes, the system was unstable and they had flickering tests but this is no reason to put the (un)tested code into production. It took a team of 5 people three weeks to stabilize the system. No new features were deployed during that time.

> If you accept that red tests are ok you are on the way to hell. You have no clue if the system behaves like you think it should.

No flickering tests are allowed. The build has to be always green. Do not accept any excuses telling you that this is ok and everything is under control.

**It is not.**

Don't do it.

<small>(Traffic Light Image from <a href="http://psdblast.com/traffic-light-icon-psd">psdblast</a>.)</small>
