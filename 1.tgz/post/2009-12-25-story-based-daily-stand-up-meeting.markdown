--- 
layout: post
title: Story based daily stand-up meeting
wordpress_id: "382"
wordpress_url: http://maxheapsize.com/?p=382
categories: Agile Scrum 
comments: true
---
<a href="http://www.flickr.com/photos/royskeane/413103429/sizes/s/"><img src="http://maxheapsize.com/wp-content/uploads/scrum.jpg" alt="&copy; royskeane@flickr " title="Scrum &copy; royskeane@flickr " width="240" height="180" class="size-full wp-image-384" /></a>

We are agile. We do Scrum. We do daily Stand-ups. 

A couple of weeks ago we changed our daily stand-up meeting. Our Scrum master came up with the idea to not go around the whole team and everybody talks about what he has done, what he will do and what the impediments are but to make it story based.

Usually after a break down everybody was working on one story, saw the task cards and made sure he did the things he was supposed to do. But this is not enough. You need to have an overview of the whole story (and the sprint). Only with that knowledge you can make sure you will meet the commitment. 

So what we started to do is a stand-up meeting based on stories. Every story has a story owner. This is either the person who first started on this story or somebody who is expert in the field worked on. Every morning he is giving a review of how 'his' story is progressing, where the problems are and how he could need help. Depending on the priority he gets everything he needs. After presenting the status to the whole team every team member involved gives a smiley on how he feels about the story and the sprint. <strong>This way everybody knows what the situation is and how the sprint is progressing</strong>.

We found this very effective and it gives every team member a much better feeling about our commitment. 

You should try it too.
