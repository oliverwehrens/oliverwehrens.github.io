--- 
layout: post
title: My MacBook Pro loves 4 GB
wordpress_id: "51"
catagories: IntelliJ Mac
wordpress_url: http://maxheapsize.com/?p=51
comments: true
---
I upgraded my MacBook Pro last week to 4 GB of RAM (up from 2GB). It's cheap (about 50 Euros) and it really makes a difference. I can give IntelliJ IDEA 1GB Xmx without any problem. No swapping anymore if I have Idea, Pixelmator, Tomcat, Maven, XMind, Firefox, Mail.app, Tweetdeck and NewsGator running at the same time. Why did I not do it earlier?
