--- 
layout: post
title: Coloring your IDE
wordpress_id: "173"
wordpress_url: http://maxheapsize.com/?p=173
categories: ide color
comments: true
---
Your IDE does a great job in helping you to program. This includes advanced features like Refactoring, Code completion and support for nifty frameworks. But it can do much more.

Most of the time you actually read the code instead writing it. So how about to make this a bit more pleasant experience (well it was for me at least). Most of the people I see use the standard color scheme of the IDE.  I was using it for way to long, that's for sure. Ever since I tweaked it just a little bit I do find my way around an editor window much more easily.

A couple of things are very easy and provided me with great value.

<img alt="Coloring your IDE" src="/static/IDEStyling.jpg" title="Coloring your IDE" width="487" height="155" />

<ul>
	<li>Give your method names a color, this will make it very explicit that something else is called here.</li>
<li>In most IDE you colorize variables with read/write access if you select them. Choose bright colors so you can easily grasp where this variable is used.</li>
<li>Magic number/strings are usually not desired. Make those very ugly to look at so you really want to get rid of them.
</li>
</ul>

Several people like to have big fonts for coding. If less text fits on one screen without scrolling you are likely to code smaller methods/classes. I'm not so sure about that one I just find it aesthetically not very pleasing.



