--- 
layout: post
title: How to refactor Spring Webflow variables in your JSF pages with IntelliJ IDEA
wordpress_id: "128"
wordpress_url: http://maxheapsize.com/?p=128
categories: Webflow Spring IntelliJ JSF
comments: true
---
We are using <strong>JSF,</strong> <strong>Facelets</strong> and <strong>Spring Webflow</strong> in the product I'm currently working on. What bugged me for some time already was that when we started to refactor the domain and the corresponding dto's the GUI was a problem since the variables which get pulled out of the webflow are just string declarations. I had to go to each xhtml file and change the code to reflect the access to the new properties.

For some reason I missed a feature of IntelliJ IDEA completely.  

If you are using Spring Webflow your code might look like this:

``` xml
<tr:outputText value="#{flowScope.myViewBean.creditCardDto.fullName}"/>
```

You get no code completion nor refactoring security. 

Now it is possible to make this a little bit <strong>better</strong>.

``` xml
<c:set value="#{flowScope.creditCardDto}" var="creditCardDto"></c:set>
<!--@elvariable id="creditCardDto" 
     type="net.wehrens.accounting.CreditCardDto"-->
<tr:outputText value="#{creditCardDto.fullName}"/>
```

With the clever Inspection '<strong>Declare External Variable in Comment Annotation</strong>' (just press Alt+Enter on the usage of creditCardDto) IDEA creates a comment annotation which tells the IDE of what type the given variable is.  Since you are using webflow, you would pull the needed variable with a c:set tag out of the flowScope (or any other scope) and then declare the variable and it's type. 

There you go. 

You can now start refactoring the creditCardDto and the GUI will reflect the changes. No more manual editing.

To make sure the comments do not get rendered out to the client (and with that the class information) you can turn that off for faclets in the web.xml  configuration.

``` xml
<context-param>
    <param-name>facelets.SKIP_COMMENTS</param-name>
    <param-value>true</param-value>
</context-param>
```

This is not specific to JSF, facelets or anything. This works with Freemaker, JSP's and others as well.

My life just got a whole lot better.
