+++
date = "2014-11-06"
title = "Wider den Monolith - Am Ende wird alles gut."
tags = ["microservice", "architecture", "monolith"]
+++

My <a href="https://jax.de/wjax2014/sessions/wider-den-monolith-am-ende-wird-alles-gut">WJax 2014</a> talk in german.

Wider den Monolith - Am Ende wird alles gut. My first talk with lots of pictures. The talk was recorded. As soon as I know the url I will post it here (and if I'm not too embarrassed :) ).

Update: Here is the <a href="https://vimeo.com/114853516">video</a> (in german).

<script async class="speakerdeck-embed" data-id="a4267b6047df01322ffa021a0fc4b210" data-ratio="1.33333333333333" src="//speakerdeck.com/assets/embed.js"></script>
