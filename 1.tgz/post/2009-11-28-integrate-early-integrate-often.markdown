--- 
layout: post
title: Integrate early, integrate often
wordpress_id: "370"
wordpress_url: http://maxheapsize.com/2009/11/28/integrate-early-integrate-often/
categories: Integration Development 
comments: true
---
<p><a href="http://www.flickr.com/photos/shuttercat7/298477892/sizes/s/" title="&copy; RogueSun Media @ flickr"><img class="alignleft" src="http://maxheapsize.com/wp-content/uploads/gears.jpg" width="240" height="180" alt="gears.jpg" /></a></p>
<p>You are doing scrum, your story is big, you really don't know much about it and the feature does not get implemented in time.</p>
<p>Sounds familiar ?</p>
<p>I had this a couple of times.</p>
<p>What turned out to be a real problem is that, tech nerds as we are, we spent most of the time coding up a nice solution (and we were almost always convinced that this was the minimum we should have done). What we <strong>underestimated</strong> was the <strong>time</strong> we would need <strong>to integrate</strong> it with the rest of the system. When we broke new ground integrating new technologies it turned out is is very easy to miss that point.</p>
<p>In theory 'just' code against a <strong>defined interface</strong> and you are all set up. In practice you will find the interface <strong>not working</strong> as intended or web services returning everything wrapped in CDATA. This is the point where you start to <strong>panic</strong>. This integration was supposed to be easy. Everything else is already working and only a couple of hours where allocated to integrate the new functionality (and sprint review is tomorrow). So it is crunch time, again.</p>
<p>What did we learn ?</p>
<p>If possible (and this is not always the case) start implementing <strong>one small feature from top to bottom</strong> all the way through your application, e.g. selling green cars through you web site. If this works you can go on and sell blue and red cars. It also helps to <strong>organize teams along user stories</strong>. This way everybody is responsible for the story.</p>
<p>If you have <strong>teams organized along responsibilities</strong> like database or GUI, the <strong>communication</strong> between the team members will <strong>suffer</strong> (since they usually sit in different rooms). Everybody tries to code up against the defined interface and the integration usually happens pretty late in the sprint. Each team claims that his stuff works against the agreed contract (but still some things do not function as they should). Just hours before the integration should be finished, it turns out the specification was not correct and other things are needed. Back to the drawing board. Overtime. <strong>Feature not implemented</strong>.</p>

<p>After you got the integration running make sure an automated test is covering it. These need to be expanded over time and you make sure from the beginning that it will always work. It would be very nice to have the integration test running before writing any actual code (read: test driven development) but this never went to well for me since the two sides are very fuzzy in the beginning.</p>

<p>My hope is that next time we come to a situation like this I remember a couple of things I wrote down here :-).</p>
