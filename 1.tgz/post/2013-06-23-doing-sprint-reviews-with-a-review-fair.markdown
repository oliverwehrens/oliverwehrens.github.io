+++
date = "2013-06-23"
title = "Doing a Sprint Review with a Review Fair"
tags = ["review", "sprint"]
+++


I'm working in an organization where we do synchronized sprints between all teams. This means every two weeks all meeting rooms are booked for retrospectives and sprint plannings. If you have around 10-20 teams distributing knowledge what's happening in the other teams is tricky. No one has the time to go to all reviews.

Enter 'Review Fair'.

<!-- more -->

The principle is quite simple. All teams show up in one (big) room. This might be the biggest meeting room you have. Every team presents for 3-5 minutes what they have done and why people should came afterwards and talk to them. They usually have some flipchart or laptop to show off stuff to lure the audicence.
After the presentations everybody knows what everybody did and can go to those which did the most important stuff for each one in the audience.

I take notes during the presentations and get no bullshit content about the stuff I'm interested in afterwards. Furthermore I get an overview what has been done and I at least heard of the things (depending on your product this might be very important).

Thanks to all the scrummasters in the company who came up with this (or wherever they got this from). It looks like <a href="http://www.scrumalliance.org/community/articles/2013/january/scaling-the-sprint-review-the-fair">Stephan Kraus and his peers at Otto</a> where among the first ones doing it.
