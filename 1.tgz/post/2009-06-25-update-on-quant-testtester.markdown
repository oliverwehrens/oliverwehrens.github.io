--- 
layout: post
title: Update on Quant TestTester
wordpress_id: "258"
wordpress_url: http://maxheapsize.com/?p=258
categories: Test Java
comments: true
---
Here is a small update on my little fun project.

I released version 0.2 of quant. Now it will recognize all TestNG annotations which do not have a TestNG group (like @BeforeMethod, @BeforeClass etc.). The method 'reportViolation' on ClassTester will now report whats wrong with the examined class.

``` java
 assertFalse(classTester.isInvalidTestClass(), 
    classTester.reportViolation());
```

Above code will now report:

<pre>
java.lang.AssertionError: 
Report for Class com.maxheapsize.quant.testclasses.SetupMethodWithoutTestGroup
Ignore abstract classes: true
Specified TestGroups :  + testUnitTest
* Methods with wrong test group: 
  - testSetUp
</pre>

In this way you know what went wrong and where to look for it.

Quant is now also available in my <a href="http://maxheapsize.com/maven2/com/maxheapsize/quant/">repository</a>. To include it add the following code to your pom.xml.

[xml]
<dependency>
    <groupId>com.maxheapsize</groupId>
    <artifactId>quant</artifactId>
    <version>0.2</version>
</dependency> 
[/xml]

For now you need to add my mvn repository to your pom. I'm about to have it mirrored to the official servers. 

Have fun.
