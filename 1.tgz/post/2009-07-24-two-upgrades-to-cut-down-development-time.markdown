--- 
layout: post
title: Two upgrades to cut down development time
wordpress_id: "286"
wordpress_url: http://maxheapsize.com/?p=286
categories: IDE 
comments: true
---
No matter how good  a developer is, with two hardware upgrades you can speed up most machines and cut down development time for everybody.

## Your big fat IDE
Depending what you use to crunch out your code, these things are eating your memory. And then you have your application server running, and an internet browser with 20+ sessions, plus Twitter, plus Photoshop, plus, plus, plus.

I used to have 2 GB RAM in my laptop and I thought it is ok. Turns out, having 4 GB,  speeds up my overall development significantly. No more swapping of programs and more programs can stay open. So far I never reached the point where my memory was exhausted (well I never really tried).

Swapping in 4 GB of RAM (DDR2) on my laptop took about 10 minutes and 50 USD. Really worth the money.

## Your mama's harddrive
My IDE of choice starts indexing all my files, scans them, creates indices (which will get updated every so often through maven) and so on. My applications server writes files, scans files for changes, deployed them and does thousand other things. This is your hard drive at work. Looking for a better solution I was looking at RAM disks to have the indices written on there but there is a more obvious solution. A Solid State Drive. 
I bought the OCZ Vertex 120 GB off Amazon. Putting this baby into a laptop can be a bit tricky (try <a href="http://eshop.macsales.com/installvideos/">OWC</a> for MacBook install videos) but is certainly doable. 

I ran some benchmark before and after to see the read/write speed up. The HD was a 7200 rpm drive and all values are in MB/sec.

<table>

<tr><th>Operation</th><th>HD</th><th>SSD</th><th>factor</tr>
<tr>
<td>Sequential Uncached Write (4k Blocks)</td><td>53.09</td><td>115.76</td><td>2.18</td>
</tr>
<tr>
<td>Sequential Uncached Write (256k Blocks)</td><td>48.29</td><td>75.53</td><td>1.56</td>
</tr>
<tr>
<td>Sequential Uncached Read (4k Blocks)</td><td>11.46</td><td>18.34</td><td>1.6</td>
</tr>
<tr>
<td>Sequential Uncached Read (256k Blocks)</td><td>42.53</td><td>115.39</td><td>2.71</td>
</tr>
<tr>
<td>Random Uncached Write (4k Blocks)</td><td>1.01</td><td>10.05</td><td>9.95</td>
</tr>
<tr>
<td>Random Uncached Write (256k Blocks)</td><td>20.67</td><td>79.03</td><td>3.82</td>
</tr>
<tr>
<td>Random Uncached Read (4k Blocks)</td><td>0.22</td><td>13.19</td><td>59.95</td>
</tr>
<tr>
<td>Random Uncached Read (256k Blocks)</td><td>7.67</td><td>104.74</td><td>13.65</td>
</tr>
</table> 

I used <a href="http://xbench.com">xBench</a> to get the read/write numbers. My laptop went up from a 118 to 194 in this benchmark. Especially the random read is where the SSD really shines. 

The SSD was about 330 USD and it took me about 40 minutes from shutdown with the old hard drive to boot up with my SSD drive.
Of course reinstalling your OS (or rolling it back from a backup) will take some time too.

Upgrading your processor is also an option but I never used that one on my Desktop machines or Laptops. If this ever was a bottle neck it usually meant that the whole machine was outdated (mainboard, bus, ram speed). But is an option as well.

I you have an older machine or even with a fast machine and you have some money left, I think upgrading these two components really makes your machine fly. 

500 USD compared to the time you save on development is about nothing. So every employer should upgrade their developers machines with RAM and SSD's. It pays out very soon (and you will make your developers happy, which is also important ;-) ).
