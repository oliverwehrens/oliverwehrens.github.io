--- 
layout: post
title: How to get your developers to pay more attention to the burn down chart (and have fun)
wordpress_id: "299"
wordpress_url: http://maxheapsize.com/?p=299
categories: Scrum Agile BurnDown
comments: true
---
For the last couple of month our scrum master always drew our daily burn down chart. Nice and fine and it always happened automagically. It came to the point that we (the developers) only occasionally paid attention to it (a little less then we should). One day our scrum master stopped doing it and forced us to do by ourselves. While it seemed a bit strange at first it turns out it was a brilliant idea. 

We are now reminded every day how much hours we burned (in contrast to we just complete cards but nobody calculates the sum and tells that everybody). If the result is far below the theoretical number of developers x 8 hours a day we quickly analyze the problem and try to solve it. We are more aware that we might be in trouble. This was not so much the case in the last sprints. 

<img alt="Self made burn down chart " src="http://maxheapsize.com/static/SelfMadeBurndownChart.jpg" title="Self made burn down chart " width="480" height="360" />

It could be that it just works because it is new but I think it is worth a short. I certainly like how everybody stands around the burn down chart and tries to do mental arithmetic.
