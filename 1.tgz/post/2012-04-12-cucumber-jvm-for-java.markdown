---
layout: post
title: "Cucumber-jvm for Java"
date: "2012-04-12"
categories: Test Java
wordpress_id: "649"
comments: true
---
In an [earlier](http://maxheapsize.com/2009/10/13/concordion-vs-cucumber-and-java-based-acceptance-testing) article I compared cucumber (with Cuke4Duke) and Concordion. It was very cumbersome due to the ruby/jruby jvm chain. Behold - the new **[cucumber-jvm](https://github.com/cucumber/cucumber-jvm)** was released. So how did it **improve** ?

Cucumber-jvm has support for many languages, e.g. Scala, Groovy, Closure and of course Java. I will focus on **Java** and **Maven**.

<!--more-->

To get you maven project going you just need to include the following dependencies:

{% include_code [Dependencies] cucumber-jvm/pom.xml %}


First thing you (or your Business Analyst or something) is doing, is **describing your feature**. It would look something like:

	Feature: Hello Car

	Scenario: Car can drive
		Given I have a car
	    When I add 4 wheels
   		Then It can drive

You need to put that into a file called Car.feature. The **.feature** extension is important.

To get all Cucumber-jvm tests off the ground we need one **test runner**. I often see it being called RunCukesTest.

{% include_code [Test Runner] cucumber-jvm/RunCukesTest.java %}

You note the Cucumber.Options annotation. It will also produce a nice html in the given directory.

Writing the test now itself is no different than with Cuke4Duke.

{% include_code [The test class] cucumber-jvm/CarTest.java %}

You need to match the **.feature** description with **@Given**, **@When**, **<strong>**@Then**</strong>** Annotation (regexp that is). Each usage of any of the annotations is called a step definition. Each one must be unique among all .feature files (as far as I can tell). The code will be executed accordingly.

A maven test will get you:

<img src="/static/cucumber-jvm-console.png" alt="Maven Cucumber-jvm test output" />

Make sure you put your .feature file in the **right location**. It needs right next to tests. I tend to put it into the resources folder in maven so it does not 'pollute' my Java source files.

<img src="/static/cucumber-jvm-source-tree.png" alt="Cucumber-jvm Test source tree" />

Finally your Html report is rendered (somewhat nicely and collapsable).

<img src="/static/cucumber-jvm-html.png" alt="Cucumber-jvm test output" />

And yes, this applies to cucumber-jvm version 1.0.2.

I hope you found that useful as very short intro into cucumber-jvm. If you are wondering if you would want to use concordion check out my older [blog post](http://maxheapsize.com/2009/10/13/concordion-vs-cucumber-and-java-based-acceptance-testing).

If I would have a choice again.**I would choose** cucumber-jvm for using a BDD tool. The plain text format makes it **easy** to read for a non programmer and it produces somewhat **good documentation** (if used well of course ;-) ). The tool chain is much smoother now and faster as well.

What I found **missing** is support for my favorite unit test tool **TestNG**. I also don't know yet how to **execute a single feature**/scenario when having multiple ones (which will be almost certain always the case).

The learn more about cucumber checkout their <a href="http://cukes.info/">website</a>.

The code used above is available on [GitHub](https://github.com/oliverwehrens/cucumber-jvm-demo)
