--- 
layout: post
title: IntelliJ IDEA Rulezzz with code completion
wordpress_id: "29"
categories: IntelliJ 
wordpress_url: http://maxheapsize.com/?p=29
comments: true
---
Today I got an interesting ctrl+space code completion in IDEA 8.1. Easteregg anyone ? :)

<img class="alignnone" title="IntelliJ IDEA Rulezzz" src="/static/IntellijRulez.gif" alt="" width="649" height="275" />

Update: ""Seems""
