--- 
layout: post
title: Hello again.
wordpress_id: "614"
wordpress_url: http://maxheapsize.com/?p=614
categories: Blog
comments: true
---
My former hoster had a system crash and it took a while to get an older backup working. Some posts are lost.

Here I am.

Thanks for the patience. 

Things still might be a little messy but I'm working on it.
