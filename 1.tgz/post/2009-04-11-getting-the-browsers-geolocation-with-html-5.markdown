--- 
layout: post
title: Getting the Browsers GeoLocation with HTML 5
wordpress_id: "200"
wordpress_url: http://maxheapsize.com/?p=200
categories: html5 geolocation
comments: true
---
Until now it was almost impossible to get the <strong>GeoLocation</strong> of a user browsing your site. You could try to use several services to more or less guess the current position. Most of the time they where using the IP address to tackle the problem. This was <strong>not very reliable</strong> when it came to mobile devices. 

Ever since the iPhone hit the market mobile adoption of the web grew exponentially. Google threw in Android and I'm sure some Windows Mobile phones do have GPS as well.  According to some talks at <a href="http://www.re-publica.de">re:publica 09</a> the big telco carriers such as T-Mobile and Vodafone see their <strong>future in the mobile (geolocation aware) web</strong>.

Even though these devices had the capabilities to get the current location,  website developers are still facing the problem that they can <strong>not access the positioning hardware of the phone</strong>. There was almost no way for (mobile) web developers to get the location of the user. There are some solution out there but you needed to install extra software which is not always possible on a phone. 

Fortunately W3C is working on the <b><a href="http://dev.w3.org/html5/spec/Overview.html">HTML 5</a></b> standard which includes JavaScript <b>access to the <a href="http://dev.w3.org/geo/api/spec-source.html">browsers location</a></b> (at least I hope it will be included). The latest beta of <a href="http://en-us.www.mozilla.com/en-US/firefox/3.1b3/releasenotes/">Firefox 3.1 (beta3)</a> already supports that API.   If you don't have a GPS system in your computer you can install an <a href="https://addons.mozilla.org/en-US/firefox/addon/8420 ">addon</a> to set your location. Rumors has it that Apple will release the upcoming <strong>iPhone 3.0</strong> OS with a location aware browser and Google will do the same with one of the next updates of <strong>Android</strong>.

To test that I wrote a small <a href="http://maxheapsize.com/static/html5geolocationdemo.html">geolocation aware demo webpage</a> with some JavaScript to pull out the information. If you are accessing it with Firefox 3.1b3+ (plugin installed and configured with your position) you will be prompted for unveiling your location to the website. If you do so it will show you your current position on the map and print out the address. 
<img alt="Allow access to the browsers GeoLocation" src="http://maxheapsize.com/static/html5geolocation01.jpg" title="Allow access to the browsers GeoLocation" width="490" height="482" />

<img alt="Showing the GeoLocation of the Browser" src="http://maxheapsize.com/static/html5geolocation02.jpg" title="Showing the GeoLocation of the Browser" width="490" height="527" />

To access this information all you need to do is:

``` javascript
    function showMap(position) {
      // Show a map centered at 
      // (position.coords.latitude, position.coords.longitude).
    }
    // One-shot position request.
    navigator.geolocation.getCurrentPosition(showMap);
```


Once this feature is widely available in mobile browsers (I do hope for this summer) my bet is that we will see a whole bunch of websites doing all sort of crazy things with these information. I'm a big Location Based Services (LBS) fan and I can't wait to see people taking advantage of this.

 <strong>Update</strong> Firefox 3.5.x uses Google's Geolocation service if no other way can be used. This is halfway accurate. It gathers information about nearby wireless access points and your computer's IP address. No more plugin needed.
