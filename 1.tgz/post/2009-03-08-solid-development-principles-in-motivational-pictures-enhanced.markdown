--- 
layout: post
title: "SOLID Development Principles In Motivational Pictures (enhanced)"
wordpress_id: "109"
wordpress_url: http://maxheapsize.com/?p=109
categories: SOLID
comments: true
---
I found <a href="http://www.lostechies.com/blogs/derickbailey/archive/2009/02/11/solid-development-principles-in-motivational-pictures.aspx">SOLID Development Principles In Motivational Pictures</a> a couple of days ago. I put one of them up in the restroom. So it turned out some clever colleague enhanced the SRP picture. Nice job.
<img alt="Single Responsibility Principle and Don't Repeat Yourself" src="/static/SingleResponsibilityEnhanced.jpg" title="SRP and DRY" width="550" height="461" />
