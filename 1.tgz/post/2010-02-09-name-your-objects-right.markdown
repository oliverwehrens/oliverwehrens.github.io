--- 
layout: post
title: Name your objects right
wordpress_id: "447"
wordpress_url: http://maxheapsize.com/?p=447
categories: Naming Development
comments: true
---
<a href="http://www.flickr.com/photos/nataliemaynor/2988366432/sizes/s/"><img alt="No Name" src="http://farm4.static.flickr.com/3220/2988366432_8f39394055_m.jpg" title="&copy; NatalieMaynor @ flickr" width="180" height="240" /></a>

Whenever you create an object you have to find a meaningful name.

While renaming later in modern IDE's is no problem at all you should not pick the first name which comes to your mind. 

Imagine you have an external fraud detection web service and it will return a 'hit' or 'miss'. How do you name this object? HitOrMiss maybe (since this is the representation you get from the webservice) ? It might describe the problem at hand. If you go with this name it will dripple down through all layers. The domain model, the dto's, services and more will now reference to this object (and create their own derivates for it). Your colleagues which code up other parts of the system will refer to it and create their own variants of the name (like structure for web pages). The wrong name is now all over your code.

So much for refactoring in your IDE. You will never catch all the places automatically where the wrong name was used.

While it <strong>seemed lost time</strong> discussing the 'right' name for 5 minutes in the beginning it <strong>saves</strong> you much more <strong>time</strong> afterwards. Of course you might get also confused a couple of weeks later remembering what this thing really does and what it is used for.

Make sure you take time in naming your objects. A <strong>wrong decision</strong> can do some <strong>harm</strong> to your code. The later it turns out that the name was not correct the much more <strong>expensive</strong> it becomes <strong>to correct</strong> this mistake. If you are not really sure how to name it, talk to your colleagues and discuss the name. A second opinion can not hurt.	

Maybe FraudDetectionResult would have been a better choice. 
