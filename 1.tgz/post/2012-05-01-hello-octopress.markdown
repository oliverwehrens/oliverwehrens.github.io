---
layout: post
title: Hello Octopress
categories: Blog
author: Oliver Wehrens
comments: true
---
Octopress. Now.

I got tired of Wordpress and choose to get something different. [Octopress](http://octopress.org). First, I like markdown and I want to become a little more fluent. Second, publishing is only a commit away. Plain html files, no php. Hosting everywhere. I can start to learn ruby. Can I ask for more?

Expect some hickups in the next days. I still need to see how the whole [disqus](http://disqus.com/) things works out.

