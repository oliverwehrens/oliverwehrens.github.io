+++
date = "2015-09-29"
title = "Entwicklung verteilter Systeme - Herausforderungen nicht nur an die Architektur."
tags = ["monolith", "architecture", "microservice", "organisation"]
aliases = [
  "/2015/09/29/Entwicklung-verteilter-systeme"
]
+++

This is my talk about **Development of distributed systems - challenges not only for the architecture**. You guessed it, it is in german. I gave this talk at <a href="http://bed-con.org/2015/talks/Entwicklung-verteilter-Systeme---Herausforderungen-nicht-nur-an-die-Architektur">BedCon 2015</a> and I will talk about it again at the <a href="http://www.the-architecture-gathering.de/indexEN.php">Architecture Gathering 2015</a> in Munich on October 22nd.

<script async class="speakerdeck-embed" data-id="af49bc1ea74b4fefaeaa3636c69542cd" data-ratio="1.33333333333333" src="//speakerdeck.com/assets/embed.js"></script>

Abstract:

<!-- more -->

Jede Platform wächst mit der Zeit. Mehr Entwickler mit noch mehr Ideen und Vorstellungen arbeiten alle gemeinsam an der Weiterentwicklung. Das System wird größer und auf viele Systeme verteilt. Häufig wird ein Technologie Stack vorgegeben, um es vermeintlich wartbarer und stabiler zu machen. Zusätzlich wird die Software oft dabei von Entwicklung zu QA weitergereicht und am Schluss von Operations deployed und betrieben. Das Ergebnis davon sind lange Releasezyklen und das verschenkte Potenzial, weil nicht die richtigen Tools genutzt werden konnten.

Dieser Vortrag erläutert unsere Leitplanken zur Entwicklung verteilter Systeme bei der E-POST. Wie erlauben wir es den 15 Teams mit 100 Personen „The right tool for the right job“ einzusetzen statt ein starres Korsett an Technologien vorzugeben? Welche Rahmenbedingungen müssen beachtet werden und wo kann ein Team autonom entscheiden wie eine Software zu entwickeln ist? Trotz wachsender Anzahl verteilter Systemen und steigender Komplexität wollen wir weiterhin eine stabile Platform zur Verfügung stellen. Es wird erklärt welche Anforderungen wir dabei in den Bereichen Architektur, Entwicklung, Testen, Deployment, Betrieb und Security vorgeben und was die Teams dabei beachten müssen.
