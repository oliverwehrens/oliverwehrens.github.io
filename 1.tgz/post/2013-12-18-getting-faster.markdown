+++
date = "2013-12-18"
title = "Getting Faster"
tags = ["production", "provisioning", "development", "deployment"]
+++


My <a href="http://www.continuouslifecycle.de/lecture.php?id=291">Continuous Lifecycle 2013</a> talk. How we got faster at deploying our software.

<script async class="speakerdeck-embed" data-id="fd5eb9e02df501313a98663820a88a30" data-ratio="1.77777777777778" src="//speakerdeck.com/assets/embed.js"></script>
