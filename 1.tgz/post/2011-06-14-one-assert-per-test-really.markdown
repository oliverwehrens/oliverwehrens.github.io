--- 
layout: post
title: One assert per test, really.
wordpress_id: "622"
wordpress_url: http://maxheapsize.com/?p=622
categories: Test
comments: true
---
Recently I was debugging my code and I could not see why my test was failing. It took me about 20 minutes to see that I violated one rule I try to follow. <strong>One assert per test</strong>. 

After <a href="http://twitter.com/#!/owehrens/status/78809340437467136">tweeting</a> it I got some reaction ranging from 'this is a very silly guideline' to 'Tests should test one thing. Often one assertion, but not always.'. I, of course, tend to agree the latter one. 

So <strong>what's in for you</strong> when you use one assert per test? What are the problems?

<!-- more -->

One the plus side:

<ol>
<li>If a tests fails, you <strong>know what is wrong</strong>.</li>
<li>You know <strong>how to name</strong> your test method, since you are just testing one thing.</li>
<li>It plays very nicely along with <strong>Test Driven Development</strong>, test and implement one feature at a time and make it work.</li>
<li>If you change one thing in your code, at best <strong>only one unit test will fail</strong> (ok, this one is hard but possible).</li>
<li>With multiple asserts you fix one assert which is broken and only then you see that the<strong> next one is broken too</strong>.</li>
</ol>

The other side:
<ol>
<li>You need to<strong> think more</strong> about the test setup, it should be possible to really just test one thing and mock the rest. Think, design for testability.</li>
<li><strong>More (test) code</strong>.</li>
<li>It looks like it is easier to have multiple asserts.</li>
</ol>

I try to do one assert per test. Once in a while my code reviewer catches one of the multiple asserts per test. Some times this is ok, some times I fix it. 

<strong>My rule is to have one assert per test almost every time.</strong> But try it at least.

And while on it, use a better assert lib. Both JUnit and TestNG Assert confuse the heck out of me. <a href="http://passion.forco.de/">Ansgar</a> introduced <a href="http://docs.codehaus.org/display/FEST/Fluent+Assertions+Module">  FEST Fluent Assertions Module</a> to our team. Now my tests look something like:

``` java Test.java
  @Test
  public void testAddSubscriber() {
    TestEventSubscriber eventSubscriber = new TestEventSubscriber();
    eventPublisher.registerSubscriber(eventSubscriber);
    assertThat(eventPublisher.getEventSubscribers()).
       containsOnly(eventSubscriber);
  }
```
If you don't know it, try it. I do like it.

Which thoughts do you have ?
