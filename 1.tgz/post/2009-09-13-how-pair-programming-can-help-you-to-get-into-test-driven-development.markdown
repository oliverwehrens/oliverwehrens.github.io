--- 
layout: post
title: How pair programming can help you to get into Test Driven Development
wordpress_id: "323"
wordpress_url: http://maxheapsize.com/?p=323
categories: TDD PairProgramming
comments: true
---
At my current job management buys into Test driven development. It slowly starts to become our primary development style.

Some <strong>advantages</strong> of TDD for me are:

<ul>
<li>Focus on problem solution</li>
<li>No unnecessary development for use cases dreamed up by the developer</li>
<li>Always make sure your code fulfills the requirements (tests)</li>
<li>If you have tests you can safely refactor your code at any time</li>
</ul>

Even though we all knew about the advantages of TDD, we figured out that we do <strong>not always write tests first</strong>. While this might me acceptable in some situations like UI tests, most of the time it is not desired. 
After seeing that problem for a couple of weeks (and always wondering how I did not write test first) all of the sudden I realized why sometimes it was easier to develop code with writing tests first and sometimes I just simply did not thought about it and had to write the tests later.

<strong>It's simply because of pair programming</strong>.

What certainly happens to me  when coding alone, is that  sometimes I get into 'crunch' mode too fast. With a second person to slow me down, we are discussing the problem and make sure we both have the same understanding of  what we are trying to achieve. During this process it is much clearer what needs to be done and what the goals are. This is a very important step. If I'm all by myself, I start writing down some classes, look at methods and I'm already thinking in code and not about the problem. Once you <strong>know what the real problem is</strong>, it is very easy to start writing your tests first. It helped me a lot. 

Where pairing also helps is to <strong>focus</strong> both programmers <strong>to stay in TDD mode</strong>. Once the driver of the pair programming couple starts to hack away code, the other will remind him to write the tests first. This is a very valuable. 

After a while I got better at test driven development, even programming alone. 

So if you recognize that you do not write tests first (but you want to) and you yet again don't know how that happened, try pair programming. You learn how to start  with TDD (and get used to it)  and get all the benefits of pair programming as well. 
