+++
date = "2013-06-03"
title = "Using KVM and Virt-Manager via XQuartz on MacOSX (and solving the keymapping trouble)"
tags = ["virtualization", "macos", "kvm"]
+++


In the last couple of months I got to play around with virtualization at work. Doing automated delivery pipleines and provisiong via puppet I decided it's time to get my hands even more dirty at home.


I got myself a <a href="http://h10010.www1.hp.com/wwpc/uk/en/sm/WF06b/15351-15351-4237916-4237917-4237917-4248009-5336624.html?dnr=1">HP Microserver N54L</a> equipped with 16 GB of RAM and 9 TB disks. I wanted ZFS and KVM. Since the machine has an AMD processor the only way was to install Linux on it. SmartOS would have been a nice choice but it only supports KVM for Intel processors.

There are some hickups to get `virt-manager` running via X11 on Macos.

You need to fix two things.

<!-- more -->

First you need to add a .Xmodmap to your home directory.

{% codeblock ~/.Xmodmap %}
clear Mod1
keycode 66 = Alt_L
keycode 69 = Alt_R
add Mod1 = Alt_L
add Mod1 = Alt_R
{% endcodeblock %}

This will enabled Left-Alt, Left-Command to exit the VNC Screen.

When you start up `virt-manager` make sure you select the approriate Keymap. Otherwise you keyboard will be garbled.

<image src="/static/virt-manager-vnc.png" alt="Virt Manager VNC Keymap settings"/>

With that you should have no problem running `virt-manager` via X11 on Macos.

If you are installing an image via commandline make sure to specify `--graphics vnc,keymap=en-us`.

Used Version:

- Virt-Manager 0.9.0
- XQuartz 2.7.2
