--- 
layout: post
title: IntelliJ Idea Plugin Property Sorter updated
wordpress_id: "219"
wordpress_url: http://maxheapsize.com/?p=219
categories: IntelliJ plugin
comments: true
---
I'm pretty busy at work right now but I could find some time to add one more feature to my little property sorter plugin for IntelliJ Idea.

Comments above property entries will now be preserved when you sort the file.

The plugin is available from within Idea or at <a href="http://code.google.com/p/ideapropertysorterplugin/downloads/list">Google Code</a>. 

<img alt="From unsorted ..." src="http://maxheapsize.com/static/CommentPropertyUnsorted.png" title="From unsorted ..." width="199" height="133" />

<img alt="... to sorted with comments." src="http://maxheapsize.com/static/CommentPropertySorted.png" title="... to sorted with comments." width="203" height="143" />

