--- 
layout: post
title: Jetbrains released a Google App Engine plugin for IntelliJ
wordpress_id: "222"
wordpress_url: http://maxheapsize.com/?p=222
categories: Google AppEngine IntelliJ
comments: true
---
Jetbrains <a href="http://plugins.intellij.net/plugin/?id=4254">released a Google App Engine plugin</a> for their IntelliJ IDE. I did not see any announcement about this at all.

<img alt="New project inside IntelliJ for Google App Engine" src="http://maxheapsize.com/static/intellijgaej.png" title="New project inside IntelliJ for Google App Engine" width="533" height="93" />


You will have a new option when creating a new project. After supplying the path to the local app engine SDK your almost good to go. I needed to add the app engine jars as libraries to my project. That being out of the way you can start coding, run you local server (a pre configured run configuration is supplied) and also deploy it to Google all from within IntelliJ. I tested it with a very basic example with local development and remote deployment and this works really nice. 

Thanks Jetbrains.

From the release notes:

This plugin provides the following features:

<ul>
	<li>option on "Technologies" page of the module wizard to quickly create:
</li>
<ul>
	<li>appengine-web.xml descriptor
</li>
	<li>App Engine Facet
</li>
	<li>App Engine Dev server run configuration 
</li>
</ul>

	<li>inspection to report forbidden code in App Engine application
</li>
	<li>run configuration for Google App Engine Dev server
</li>
	<li>action for uploading an application to Google (Tools | Upload App Engine Application) 
</li>
</ul>

