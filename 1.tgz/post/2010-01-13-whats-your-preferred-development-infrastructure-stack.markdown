--- 
layout: post
title: What's your preferred development infrastructure stack?
wordpress_id: "435"
wordpress_url: http://maxheapsize.com/?p=435
categories: Development Infrastructure
comments: true
---
In Response to <a href="http://raibledesigns.com/rd/entry/what_s_your_preferred_development">Matt Raible's</a> question about my preferred development stack.

### Source control

In my own development project I switched to <a href="http://git-scm.com">Git</a> some time ago. I was using svn and before that cvs for a couple of years. Git just makes it easy to try out small ideas very quickly without reverting the code. We will introduce Git at work pretty soon (I hope).

### The Atlassian cloud

I was using <a href="http://www.atlassian.com/software/confluence/">Confluence</a> as a Wiki in my open source project and my current employer <a href="http://www.hypoport.de">Hypoport</a> uses it as well.  Bug tracking is pretty much a task of <a href="http://www.atlassian.com/software/jira/">Jira</a>. Those two integrate very nicely. You can have ping backs in your Jira Ticket from Confluence, so you see all related files. I would love to use <a href="http://www.atlassian.com/software/fisheye/">FishEye</a> but I'm not sure how to justify the costs and what the added value is in our case.

### The Code

I'm pretty much sold to <a href="http://www.jetbrains.com/idea/index.html">Jetbrains IntelliJ Idea</a>. I'm using it for 5 years now. With it comes <a href="http://www.jetbrains.com/teamcity/">Teamcity</a>. It's a very nice continuous integration tool where the biggest plus (among other things) is the delayed (and pre tested) checkin. No more late night checkins which break the master. We just rolled out the latest version which has a much nicer Git integration (so we can make the switch).

So it comes down to:

### The List
<ul>
<li>Source control: <b>Git</b></li>
<li>Wiki: <b>Atlassian Confluence</b></li>
<li>Continuous Integration: <b>Jetbrains Teamcity</b></li>
<li>Bugtracker: <b>Atlassian Jira</b></li>
</ul>

We are about to use <a href="http://sonar.codehaus.org/">Sonar</a> for code analysis and development over time, but this is just in the beginning.

What's yours ?
