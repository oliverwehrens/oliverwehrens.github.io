--- 
layout: post
title: 5 code metrics you need to watch
wordpress_id: "459"
wordpress_url: http://maxheapsize.com/?p=459
categories: Code Metrics Development
comments: true
---
<a href="http://www.flickr.com/photos/iliahi/2606644514/sizes/s/" title="Â¬Â© Biking Nikon PDX@flickr" ><img class="alignleft" src="http://farm4.static.flickr.com/3241/2606644514_b6f294fb2e_m.jpg" title="&copy; Biking Nikon PDX@flickr" width="240" height="167" /></a>

Developing software ain't easy.

How do you know how you are doing ?

You could start <strong>collecting metrics</strong> about your code. These can give you some indication how maintainable and reliable it is.

The metric which come to mind to the most people is <strong>code coverage</strong>. Some people say it must be near 100%, other say 80% is a good number. At the end it can't tell you if you are doing great or good. The only thing you might read from it is that a <strong>low number</strong> indicates a <strong>potential problem</strong>.

<!-- more -->

Duplication is another one you should look out for. A high number of <strong>duplicated code</strong> might bring up the problem that a bug was fixed in one place but lives on in other. If you are doing code generation (e.g. from WSDL's) you might have a lot of duplicated code reported to you. A closer inspection is needed to really make sure this is a problem in the code you have written and is not auto generated.

<strong>Test success</strong> is not a metric you should be worried to much about. It just needs to be <strong>100% </strong>at every checking in a shared repository. <strong>No discussion</strong>.

<a href="http://en.wikipedia.org/wiki/Cyclomatic_complexity"><strong>Cyclomatic complexity</strong></a> let's you measure the number of linearly independent paths through your code. A high number means a more complex code. A complex code base is hard to maintain and involves a lot of work to adopt it to new requirements.

Dependencies between packages is another important value to check on (see <a href="http://www.objectmentor.com/resources/articles/granularity.pdf">Uncle Bob's paper on Acyclic Dependency Principle</a>). Basically it revolves around that packages should not have <strong>cyclic dependencies</strong> between them since this does have an impact on releasing and testing (and therefore coding).  A change in one package could trigger a whole system build to make sure everything works together.

Tools like Findbugs let you define rules to which your code should comply to. This is great because it is tailored to your code/company and ensures you control and fine tune the measures. Or so. It requires some time to define these rules. They need to be refined over time and you have to understand them to make use of it. Of course you can leave out some of these and reduce complexity. Do not underestimate the effort to implement these.

This rounds up the metrics you can get from your code base.

But wait, there is <strong>more</strong>.

A valuable metric is the <strong>meantime between reporting</strong> a feature or bug <strong>and fixing</strong>. This gives your team (and management of course) a rough estimate how fast you can react to market changes.

To get an estimate of the mean time before a failure happens you can <strong>measure the time between two bugs</strong>. The higher the number the better. Current reported bugs per lines of code can also be measured. These metrics will give you some confidence in your code base.

At the end of the day the <strong>ultimate measure</strong> is the money on the company's bank account. If this is not working out you are in trouble.
## How to get all of these ?
There are some static code analysis tools to get you started. I only can talk about Java related tools but there <a href="http://en.wikipedia.org/wiki/List_of_tools_for_static_code_analysis">are others</a> as well.
<ul>
	<li><a href="http://checkstyle.sourceforge.net/">Checkstyle</a></li>
	<li><a href="http://findbugs.sourceforge.net/">FindBugs</a></li>
	<li><a href="http://pmd.sourceforge.net/">PMD</a></li>
	<li><a href="http://cobertura.sourceforge.net/">Cobertura</a></li>
	<li><a href="http://www.headwaysoftware.com/products/structure101/index.php">Structure 101</a></li>
	<li><a href="http://sonar.codehaus.org/">Sonar</a></li>
</ul>
To get more information about your bugs should query your bug tracking system like <a href="http://www.atlassian.com/software/jira/">Jira</a> or <a href="http://www.bugzilla.org/">Bugzilla</a>.
## Summary
There are much more numbers out there but I think these are the ones you should always keep an eye on.

Look out for
<ul>
	<li>Code Coverage</li>
	<li>Duplication</li>
	<li>Cyclomatic complexity</li>
	<li>Cyclic dependencies</li>
	<li>Test success</li>
	<li>Time to market</li>
	<li>Mean time between failure</li>
</ul>
What metrics do you look out for ? <strong>Let me know </strong> in in the comments and why.
