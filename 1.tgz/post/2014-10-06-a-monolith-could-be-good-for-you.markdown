+++
date = "2014-10-06"
title = "A Monolith could be good for you"
tags = ["monolith", "architecture"]
+++

Everybody says monolithic applications are bad. I usually hear things like:

- Tiny changes need full redeployment (maybe even with downtime)
- Limited agility
- Easy to get a big ball of mud

So why would you like to have a monolith?

<!-- more -->

![Monolith](/static/monoliths.jpg)

There are many definitions of a monolithic application. There are tons  for microservices.

A Monolith has it's advantages. There are companies which are successful with monolithic applications.

You start faster.
===

It's one codebase. All in one editor. Only one team working on it. Why would you split that into multiple projects, thinking about interfaces and deployment? If you start with a new project I would recommend to do it just like that. Dealing with multiple services right from the start adds overhead and complexity which you can avoid.

You ~~can~~ must modularize the monolith.
===

Even if everything is in one codebase, you can still structure it. Of course we all do it, right? In Java you typically use packages. One trap which you can easily fall into is to structure it along the technology. Does Frontend, Backend, Database sound familiar? I still see that very often, because as programmers we think in technology.

Try to do it along business logic. This is much harder but it will make refactoring much easier because changing a thing in one business aspect  is much less likely to break another business case.

Make use of things like private and package protected access. It's a great way to show the intent of the code to the reader.

Testing is easier.
---

Since all is in one place. Testing is much easier. It will be never easier than that.

Deployment is easier.
---

It is one application. How hard could it be to deploy it. Sure it can be, but just like testing...it will just grow from here. Enjoy it while you can.


So why change that?
---

Good question.

If you have a (relativly) small code base and one team. I guess it should stay like this.

If the project grows in terms of team members, teams and/or code base you will start to have a new slew of problems.

More people means, more intercation, more explaining, more code/architecture styles ... well more of everything.

At this point you might need to think about splitting the code. If you did the base work in the monolith already you might have a good start into the world of distributed systems. You need to carefully think about if you want to move the complexity one level up and how you will manage it there.

If you did not modularize your monolith, you end up with [big balls of distributed mud](http://www.codingthearchitecture.com/2014/07/06/distributed_big_balls_of_mud.html) later.

> If you can't build a monolith, what makes you think microservices are the answer?


To cite Martin Fowler:

> First Law of Distributed Object Design: "don't distribute your objects".

It's hard.

If you want to learn more about microservices and monoliths come and join us at the [microXchg 2015](http://microxchg.io) community conference in February in Berlin, Germany.

<small>Picture by [Antonis Lamnatos](https://www.flickr.com/photos/lamnatos/2266234773/in/photolist-4sg3Dk-2MKSNr-akQfJA-gtZneb-ef6qrS-4rXk8h-rVDD4-cykvPW-9iwEH1-g9b8zY-6YWSXZ-aFi219-9m8k-2Sx3D-hrLrEM-f4ADq8-5v9Mo5-8V9pVW-e9Wm3B-9ySZxU-4Xg2pr-9RGCGM-nyKzAC-7Uwrzi-6Z1RoS-9eWnWt-8NLpS2-6o1TD2-4AVGEW-99BadQ-rZFN8-9LCr5A-aWCXi4-2ixBeR-dYp5cN-acMxYe-iTx9TF-4xw2Bn-akDMXG-udUsG-5TxKx4-7aFXXn-4bi8H-8VQD1W-6TpC3E-6eiRbJ-nvgxnX-5mfGTh-8Ktoq-6dgxvy) licensed under [Creative Commons 2.0](https://creativecommons.org/licenses/by/2.0/)</small>
