--- 
layout: post
title: A Quick Look at Google App Engine for Java
wordpress_id: "182"
wordpress_url: http://maxheapsize.com/?p=182
categories: AppEngine Google Java
comments: true
---
<img alt="" src="http://maxheapsize.com/static/appengine.gif" class="alignleft" width="145" height="111" />At <a href="http://code.google.com/campfire/">Campfire One</a> Google <a href="http://googleappengine.blogspot.com/2009/04/seriously-this-time-new-language-on-app.html">announced</a> their App Engine for Java (this was in the rumor mill for a couple of days already). The first 10,000 developers would get an early look at App Engine's Java language support. I would have almost missed it. Some tweets reminded me of registering with Google. I heard of AppEngine before but the fact that it was only available for Python did not make it very attractive to me. Now the game changed a bit with introducing Java (and <a href="http://groups.google.com/group/google-appengine-java/web/will-it-play-in-app-engine">other JVM languages</a> (JRuby, partial Scala ...), well <a href="http://blog.springsource.com/2009/04/07/write-your-google-app-engine-applications-in-groovy/">Groovy</a> for sure, <a href="http://olabini.com/blog/2009/04/dynamic-languages-on-google-app-engine-an-overview/">Ola Bini</a> has more on that).

After <a href="http://appengine.google.com/">registering</a> with my Google ID they wanted to verify my account with a sms text message. Google is just listing  3 countries and then 'Other' for sms verification and I expected it would not work with a german cellphone. But it did ;-).

The <a href="http://code.google.com/appengine/docs/java/gettingstarted/">Tutorials</a> on their site are working nicely (even if you don't have Eclipse which they are always referring to). Just follow the instructions step by step, use ant and the command line to get through the examples. Don't copy the template project, this is not in line with the documentation.

In the last hour or so I went from nothing to a running <a href="http://maxheapsize.appspot.com/">Guestbook App at Google (try it!)</a>. Once you get the environment right, the code is pretty straight forward.

I see a couple of things which I do like about the App Engine.

<strong>Support for Google Id and Sign In</strong>
AppEngine support sign in with an Google ID with 2! lines of code. Great. I don't want to worry about that (this generates the Google login page and redirects).
<pre name="code" class="java">
UserService userService = UserServiceFactory.getUserService();
User user = userService.getCurrentUser();
</pre>

<strong>Automagic Persistence</strong>
With simple annotation you persist your objects. No mapping, no nothing. You can configure if you want to be using JDO or JPA. No database hassle or whatsoever. Of course it needs to be seen how this work with more complex domain models. 

``` java
@PersistenceCapable(identityType = IdentityType.APPLICATION)
..
    @PrimaryKey
    @Persistent(valueStrategy = IdGeneratorStrategy.IDENTITY)
    private Long id;

    @Persistent
    private User author;

    @Persistent
    private String content;

    @Persistent
    private Date date;
...
```

<strong>Local Development - Remote Depolyment</strong>
Everything works locally. If you deploy it to Google it uses the Google facilities. I don't have to worry (deployment is one ant command).

<strong>Scalability and free Use</strong>
If your application is successful you can grow with Google. More Resources at your fingertips. Of course this costs money (but you should make money at this point right?). If you are beyond the <strong>free</strong> 10 GB bandwidth in/day, 10 GB bandwidth out/day, 5 million pageviews a month, 46.3 cpu h/day and 1000 emails/day you pay:

<ul>
<li>CPU Time 	$0.10/CPU hour </li>
<li>Bandwidth Out $0.12/GByte </li>	
<li>Bandwidth In $0.10/GByte </li>	
<li>Stored Data $0.005/GByte-day</li>
<li>Recipients Emailed $0.0001/Email </li>
</ul>

<strong>Monitoring</strong>
You get nice and detailed overview of the status of you application. You can upload new version any time and go live on demand.
<img alt="Google AppEngine Dashboard" src="http://maxheapsize.com/static/GoogleAppEngineDashboard.jpg" title="Google AppEngine Dashboard" width="450" height="303" />

This this is limited access and Google titles it 'early look' there must be some gotchas but I hope they will get worked out. Of course you will depend on Google's code but I could imagine with a good abstraction layer you can minimize the dependencies to the AppEngine (although replacing some services you might need to use could be hard).

The downside of using it are (gathered from various sources)

<ul>
<li>No own threads</li>
<li>Restrictions of java.io.File</li>
<li>Restrictions on reflection</li>
<li>Maximum of 30 seconds per request</li>
<li>An application may not open sockets</li>
</ul>


For sure there are some more benefits in hosting with Google (I guess the same goes for Amazon with S3/EC2). In the past I heard from a couple of startups using those kind of services but I never imagined that it would be that easy.  As I said, I was up and running in under one hour.

I certainly will use AppEngine for a small application in the near future.
