--- 
layout: post
title: One year of blogging
wordpress_id: "441"
wordpress_url: http://maxheapsize.com/?p=441
categories: Blog
comments: true
---
<a href="http://www.flickr.com/photos/mrs_logic/3799729875/sizes/s/"><img alt="&copy; Mrs Logic @ flickr" src="http://farm3.static.flickr.com/2509/3799729875_16098fe242_m.jpg" title="One Year" width="171" height="240" /></a>

One year ago I started to blog again. Time for a little recap.

<strong>Why did I do it ?</strong>

I use this blog to write down my own thoughts about software and development. This is for my own reference but also it is a little way to give something back to the world wide community in return for all the useful stuff I do read on the net.

I noticed how this also made me a <a href="http://www.joergm.com/2010/01/why-all-programmers-should-blog/">better programmer</a>. Try it out by yourself. Having a professional blog is also a good way for <a href="http://www.chrisbrogan.com/develop-a-strong-personal-brand-online-1/">Personal branding</a>.


<strong>Stats for the last 12 months</strong>

I love number so here they are:

About 15.000 unique visitors
About 20.000 pageviews

<em>Traffic</em>

20.64 % Direct Traffic
36.34 % Referring Sites
42.44 % Search Engines

Highest page views on one day: the <a href="http://maxheapsize.com/2010/01/04/using-selenium-2-for-web-testing/">Selenium 2</a> post, 620 pageviews (ok, this was big link of the day at dzone.com).

<em>Countries</em>

I had visitors from 120 countries.

3362 visitors from United States 
2090 visitors from Germany 
776 visitors from United Kingdom 

<em>Top posts</em>

<a href="http://maxheapsize.com/2009/04/11/getting-the-browsers-geolocation-with-html-5/">GeoLocation with HTML5</a> 2670 pageviews
<a href="http://maxheapsize.com/2009/07/03/getting-started-with-jsf-2-and-maven/">JSF 2 and maven</a> 2607 pageviews
<a href="http://maxheapsize.com/2010/01/04/using-selenium-2-for-web-testing/">Selenium 2</a> and <a href="http://maxheapsize.com/2009/10/13/concordion-vs-cucumber-and-java-based-acceptance-testing/">Concordion vs. Cucumber</a> each 1566 pageviews

I have 142 RSS subscribed readers.

All in all, not too shaby ;-).

<strong>Thanks</strong>

Thanks to everybody for reading my thoughts. Thanks for the comments and hints.  

I'm looking forward to the next year. It is going to be a great one.
