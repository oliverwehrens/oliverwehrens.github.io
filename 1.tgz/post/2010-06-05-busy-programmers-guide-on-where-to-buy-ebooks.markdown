--- 
layout: post
title: Busy Programmers Guide on where to buy eBooks
wordpress_id: "557"
wordpress_url: http://maxheapsize.com/?p=557
categories: Books
comments: true
---
Every Programmer needs to read books. Usually you would get some packages from Amazon (or your favorite retailer) and read through them. 
Now with devices like the Kindle and iPad (and Nook and...) things will change. No more carrying around a couple of hundred pages of paper. Only some Megabytes on Gigabytes of storage. The displays nowadays are good enough and the battery is not a problem for the most part.

Now the tricky part, you want your books in a format which you can read on many devices. The obvious candidates are:

<!-- more -->

<ul>
	<li><strong>PDF</strong> : Lots of books are available in pdf, be sure not to get DRM PDF. Not all reader software can show this.</li>
	<li><strong>Kindle (.azw)</strong> : The Kindle Software is available for many devices (iPad, PC, Mac and of course Kindle devices).</li>
	<li><strong>mobi</strong> : Some stuff is available in .mobi as well.</li>
	<li><strong>ePub</strong> : This is also wide spread. A DRM'd version is also available. So make sure your reader is able to handle that.</li>
</ul>
The best choice is of course to get non protected (read non-drm) books. To me pdf, epub and azw (I know, drm) all look nice. It is just a question of your reading device. 



Formats are important but and the end, where do I get my books?

I picked a few publisher and looked on what they provide. Amazon is a different thing anyway. I compare the prices to their Kindle format.

<style>
td { width: 80px; background #ccc; text-align: center }
th { text-align: center }
table { border: 1px dotted black; padding: 10px; }
</style>

<b><a href="http://manning.com/catalog/mobile/">Manning</a></b> - <a href="http://www.manning.com/bibeault/">jQuery in Action</a>
<table>
<tr><th></th><th>Print Book</th><th>eBook</th><th>Amazon</th><th>Kindle</th></tr>
<tr><td><img src="http://ecx.images-amazon.com/images/I/51srSzNztpL._SL160_PIsitb-sticker-arrow-dp,TopRight,12,-18_SH30_OU01_AA115_.jpg"></td><td>$39.99 (+ PDF)</td><td style="background: #8BC95A">$24.55 (.epub, pdf, .mobi)</td><td >$29.69</td><td >Could not find Manning titles for Kindle</td>
</table>

<b><a href="http://www.wrox.com/WileyCDA/Section/All-Titles-Books-Ebooks-for-Programmers-ASP-NET-C-Javascript-More.id-105077.html">Wrox</a></b> - <a href="http://www.wrox.com/WileyCDA/WroxTitle/Professional-XMPP-Programming-with-JavaScript-and-jQuery.productCd-0470540710.html">Professional XMPP Programming with JavaScript and jQuery</a>
<table>
<tr><th></th><th>Print Book</th><th>eBook</th><th>Amazon</th><th>Kindle</th></tr>
<tr><td><img src="http://ecx.images-amazon.com/images/I/51zBSAaHI8L._SL160_AA115_.jpg"></td><td>$49.99</td><td>$49.99 (pdf, could be DRM)</td><td >$31.49</td><td style="background: #8BC95A">$19.54</td>
</table>

<b><a href="http://oreilly.com/ebooks/">OReilly</a></b> - <a href="http://oreilly.com/catalog/9780596809485/">97 Things Every Programmer Should Know</a>
<table>
<tr><th></th><th>Print Book</th><th>eBook</th><th>Amazon</th><th>Kindle</th></tr>
<tr><td><img src="http://ecx.images-amazon.com/images/I/51uSFVY7zjL._SL160_PIsitb-sticker-arrow-dp,TopRight,12,-18_SH30_OU01_AA115_.jpg"></td><td>$29.99 ($32.99 Book + eBook)</td><td>$23.99 (Android, Mobi, PDF, ePub) </td><td >$19.79</td><td style="background: #8BC95A">$18.85</td>
</table>

<b><a href="http://apress.com/ecommerce/ebookshop">APress</a></b> - <a href="http://apress.com/book/view/1430219483">Coders at Work</a>
<table>
<tr><th></th><th>Print Book</th><th>eBook</th><th>Amazon</th><th>Kindle</th></tr>
<tr><td><img src="http://ecx.images-amazon.com/images/I/51DEnAtKzBL._SL160_PIsitb-sticker-arrow-dp,TopRight,12,-18_SH30_OU01_AA115_.jpg"></td><td>$29.99</td><td>$20.99 (pdf) </td><td style="background: #8BC95A">$18.85</td><td>$19.79</td>
</table>

<b><a href="https://www.packtpub.com/">Packt Publishing</a></b> - <a href="https://www.packtpub.com/solr-1-4-enterprise-search-server/book">Solr 1.4 Enterprise Search Server</a>
<table>
<tr><th></th><th>Print Book</th><th>eBook</th><th>Amazon</th><th>Kindle</th></tr>
<tr><td><img src="http://ecx.images-amazon.com/images/I/5141rH49WML._SL160_AA115_.jpg"></td><td>$40.49</td><td style="background: #8BC95A">$30.59 (pdf)</td><td >$35.39</td><td> Could not find any Packt titles for Kindle</td>
</table>

<b><a href="http://pragprog.com/">Pragmatic Bookshelf</a></b> - <a href="http://pragprog.com/titles/vsscala/programming-scala">Programming Scala: Tackle Multi-Core Complexity on the JVM</a>
<table>
<tr><th></th><th>Print Book</th><th>eBook</th><th>Amazon</th><th>Kindle</th></tr>
<tr><td><img src="http://ecx.images-amazon.com/images/I/51hfd66G1pL._SL160_AA115_.jpg"></td><td>$34.95 ($43.75 book + pdf,mobi,epub)</td><td style="background: #8BC95A">$22.00 (pdf,mobi,epub)</td><td >$23.07</td><td> Could not find any titles for Kindle</td>
</table>

### Conclusion:


Amazon shines, if they can offer eBooks there are priced very low, sometimes even the printed book is cheaper then the publisher eBook. If you can cope with Amazons format, a Kindle (or a Kindle app) is the way to go. Instant download, sharing between devices, very nice. I can now carry around dozens of books which I get for very cheap.
<a href="http://twitter.com/manningbooks">Mannings</a> and <a href="http://twitter.com/wrox">Wrox</a> have Twitter accounts where they announce good discounts on printed and electronic books. Worth to checkout. APress eBooks are always 30% cheaper as the cover price of the printed one.
Most of the publishers do have an extensive part of their books available as eBoooks.

Getting the eBooks is especially nice for folks living outside the US, e.g. '97 Things Every Programmer Should Know' is listed for about $27 at Amazon Germany. So I save about 40%. I will buy more books now since they are now much cheaper and more accessible to me.

My reader is an iPad with iBooks for epubs, the Kindle app for Amazon's selection and GoodReader for Pdf's. 

Does anybody have good or bad experience with eBooks? 


