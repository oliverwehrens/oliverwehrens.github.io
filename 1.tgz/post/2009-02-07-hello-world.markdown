+++
date = "2012-04-12"
title = "Starting again ..."

+++

<p>After about a year of not blogging, I'm getting back to it. I have still some infrastructure work to do but it's coming. Just wait a little bit more.<br></p>
