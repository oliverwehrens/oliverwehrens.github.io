--- 
layout: post
title: Updated Scrum Board Cheat Sheet with Story Owner
wordpress_id: "119"
categories: Scrum Agile Board
wordpress_url: http://maxheapsize.com/?p=119
comments: true
---
So just in the last sprint we (re) discovered that we need an<strong> owner of each story</strong>. A person who makes sure things are going smoothly and takes care that everything is done in a way so we can fulfill all acceptance tests. At sprint start the person which feels the strongest about the first story will be owner and he will drive the story. 
Very often we do operate in a <strong>king and servant</strong> model. The king (story owner) calls as many servants he needs to get 'his' story (with the highest priority) done. If this story does not scale to the full team the others are starting on the next story. Again, a story owner (king) is chosen (or whoever wants to drive the story). Of course story priority is always determining the order of allocating resources to finish the job. 
To formalize the story owner a little bit we do write down the name of the person in the upper right corner of the story card. I updated the scrum board cheat sheet.

Get version 1.1 of the <a href="/static/ScrumBoardCheatSheet.pdf">Scrum Board Cheat Sheet</a>.
