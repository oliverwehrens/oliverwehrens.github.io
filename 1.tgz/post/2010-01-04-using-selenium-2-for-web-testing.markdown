--- 
layout: post
title: Using Selenium2 for web testing (and not Selenium IDE)
wordpress_id: "393"
wordpress_url: http://maxheapsize.com/?p=393
categories: Selenium2 Test
comments: true
---
### Selenium IDE
<a href="http://seleniumhq.org">Selenium</a> is well know for automatic testing web pages. It does support many <a href="http://seleniumhq.org/about/platforms.htm">browsers, operating systems and languages<a/>. A <a href="http://seleniumhq.org/projects/ide/">Selenium IDE</a> exists to aid you creating automated tests. 

<img alt="Selenium" src="http://maxheapsize.com/static/selenium.png" title="Selenium IDE" width="303" height="177" />

It is possible to write extensions in JavaScript to have data driven tests. If you organize your selenium tests in a way that you split  the pages and forms in components, you can  load up new data for the tests (written in xml) to fill out forms differently for each use case. The Selenium IDE will be of a great help here since you start develop the tests in the IDE and later 'just' parametrize the pages. With a couple of more javascript magic you can run these as well in <a href="http://seleniumhq.org/projects/remote-control/">Selenium Remote Control</a> (Selenium RC for short). This even works for running  the tests in continuous integration systems like Hudson or Teamcity.

Great Stuff.

### The problem.

The drawback coding up your tests with the Selenium IDE is: <b>HTML</b>.  

You will end up with some test suites including many test scenarios. It will be one big ball of 

``` html
<tr>
  <td>type</td>
  <td>accountnumber:Value</td>
  <td>82892892811</td>
</tr>
<tr>
  <td>type</td>
  <td>accountAmount:Value</td>
  <td>2345.33</td>
</tr>
```

You will build components and you will end up with GotoIf and Label statements. Back to Basic programming from the 80ties. Without more javascript extensions you also can't reuse combinations of scenarios. 

While this works pretty ok: I'm a programmer and do have a <strong>problem</strong> with the <strong>quality of the produced code</strong>. It's <strong>easy to mess up</strong>. It's <strong>not safe for refactoring</strong>. To extend functionality you need to have javascript knowledge. Depending on your company profile (e.g. java shop) , this might be a problem.  Having a dedicated tester on the team certainly helps to overcome these obstacles, but if everybody in the team just once in a while looks into the Selenium IDE tests, the quality and the reliability of the code will not improve. Not to mention all the <strong>copy and paste</strong>. Been there, done that.

### Selenium 2

A much nicer approach for me would be something like this:

``` java
WebDriver driver  = new FirefoxDriver();
AppWebTest test = new AppWebTest(driver, "http://myapp.com/login");
LoggedInUser user = test.login("user", "password");
Account account = user.createNewAccount("DemoAccount");
account.addPerson(PersonFactory.createPersonWithNoIncome());
...
account.verify();
```

This would log in a user, creates an account and assigns a person to it. Everybody could <strong>read and understand</strong> it. Furthermore you can easily reuse components and logic. I would imagine that creating a DSL, matchers and finders is everything one would need to have a very nice test scenario.

All that is already possible with Selenium 1 and the language bindings (more or less). 

Just with the release of the first alpha of Selenium 2 mid december 2009 it became just a little bit easier.

Selenium 2 is the <strong>combined effort</strong> of Google's Webdriver and Selenium. Webdriver tries to <a href="http://google-opensource.blogspot.com/2009/05/introducing-webdriver.html">tackle</a> Seleniums problems with Javascript and the security model as well as the complex Selenium RC API. 

<blockquote>
Selenium is written in JavaScript which causes a significant weakness: browsers impose a pretty strict security model on any JavaScript that they execute in order to protect a user from malicious scripts. 
...
Additionally, being a mature product, the API for Selenium RC has grown over time, and as it has done so it has become harder to understand how best to use it. For example, it's not immediately obvious whether you should be using "type" instead of "typeKeys" to enter text into a form control. Although it's a question of aesthetics, some find the large API intimidating and difficult to navigate.
</blockquote>

Webdriver does not use JavaScript to control the web browser but <strong>uses native controls</strong>, e.g. an extension for Firefox or the native automation extensions of IE. Furthermore it introduces an object based API instead of following Seleniums directory based approach.

So given the above example the login method would look something like this:

``` java
 public LoggedInUser login(String userName, String password) {
    driver.get(url);
    driver.findElement(By.id("user")).sendKeys(userName);
    driver.findElement(By.id("password")).sendKeys(password);
    driver.findElement(By.id("login")).click();

    LoggedInUser user = new LoggedInUser(driver);

    WebElement startPage = driver.findElement(By.id("startPage"));

    assertThat(startPage().getText()).isEqualTo("Start");
    return user;
  }
```

You can take this to any level. It took me just a few hours to model the above use case with componentized input elements. 

With a bit more abstraction addPerson looks something like the following code. Whatever is needed to add a person to an account will be replayed. This is what Selenium IDE would normally do.

``` java
public void addPerson(Person person) {
    jumpToAccountOverView();
    clickOnLink("menu:Overview");
    clickOnLink("table_personTable:link_newPerson");

    inputGuiElement(person.getTitle());
    inputGuiElement(person.getLastName());
...
    clickSave();
```

And now for the best part. You <strong>don't really need a real web browser</strong>. Selenium 2 supports 4 WebDriver: 
<ul>
<li>Firefox</li>
<li>Chrome</li>
<li>Internet Explorer (on Windows)</li>
<li>HtmlUnit</li>
</ul>

### HtmlUnit

With enabled JavaScript on HtmlUnit (it uses Rhino, so not all JavaScript tricks might work, could be a drawback depending on your scenario) I can run my test as <strong>TestNG or JUnit</strong> test case. No need for a Selenium RC anymore. <strong>No  browsers running locally</strong> or on remote machine listing to ports to execute tests and transmitting results back. 

It is very useful to have the Selenium RC take screen shots during it's run. Selenium 2 can't do this right now (and with HtmlUnit never can). But by simply integrating some logging in the components and elements and you know right away where things went wrong. 
Developing with the <strong>Selenium IDE</strong> might seem like a must, but during the work on my prototype all I needed was Firebug and a XPath Searcher. I <strong>did not miss it</strong> at all. To do integration tests you could test all components independently and one at a time. Once these work, chain them together and let them run as unit tests. Did I mention <strong>HtmlUnit is fast</strong> ? 

### Conclusion

I barely dug into the webdriver code, I played around with it for a couple of hours and I'm sure there more is stuff (and bugs) to find. Given that Selenium 2 is in alpha 1 stage right now I expect very nice things coming out of it. It certainly looks like the way to go. 

Another strong contender is <a href="http://webtest.canoo.com/webtest/manual/WebTestHome.html">Canoo WebTest</a>. I will have a look at this one in another post.

<strong>Update Ajax and HtmlUnit</strong> 1/5/2010 

It does not seem to work. You need a real browser to get dynamically content re-rendered through Ajax. 

A method waiting for an id to be rendered (or timeout after x seconds) could look like this:

``` java
  public void waitForElementOrTimeout(String idToWaitFor, int timeout) {
    long end = System.currentTimeMillis() + timeout * 1000;
    RenderedWebElement resultsDiv = null;
    while (System.currentTimeMillis() < end) {
      try {
        resultsDiv = (RenderedWebElement) driver.findElement(By.id(idToWaitFor));
      }
      catch (NoSuchElementException e) {
        // 
      }
      if (resultsDiv != null &amp;&amp; resultsDiv.isDisplayed()) {
        break;
      }
    }
    assertThat(resultsDiv).isNotNull();
  }
```

This will either find the element specified or throw an assertion (updated example from the selenium 2 page).
