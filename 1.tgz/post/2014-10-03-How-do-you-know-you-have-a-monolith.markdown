+++
date = "2014-10-03"
title = "How you might know that you have a monolith"
tags = ["monolith", "architecture"]
aliases = [
  "/2014/10/03/How-do-you-know-you-have-a-monolith/"
]
+++

You start your green field project and keep working on it. It grows and grows and grows. You feel comfortable with it and it could not be better. Because more needs to be done/the product is successful another team is added.

<!-- more -->

![Monolith](/static/monolith150150.jpg)

If this **new team starts** complaining that the setup if very complicated and they do take a lot of time to get started:
**Listen carefully**. Of course everybody will complain if they get thrown into another code base, nobody understands the code and of course everybody would have it done differently.

There is a good chance that they say something which you don't like to hear and **they are right about it**. You have built a piece of software which grew very large and maybe a single person can not understand the code base anymore.

If you think you have a modular software project but you need to bring everything together to test things out they might be right about it.

Don't get into a fight with the other team and insist that you are right (since you know how things work) and they are wrong. It is way to **easy too get upset** if somebody does not like your baby and critize it. The other team want's to help and will very likely stay longer on the project. They are not dumb people so listen to their problems carefully. It's like a code and architecture review from outside your tunnel. **Don't ignore the valuable information you can gather**.

If they do complain about how all things assembled and deployed at the end and that this takes very long and is compliacted ... **you might have built a monolith**. You might not have seen it that way because you are just used to it.

YMMV

<small>(Picture by <a href="https://www.flickr.com/photos/wwward0/13233527895/in/photolist-maphN4-6YWSLK-4h6k-8zAydR-5mtbMq-aRBpj8-hV5Cms-hSTpRS-5fgZ1r-6E3y1j-84ynMr-5DRLd1-5eiMLK-QZ5zb-wZngC-9Uq8Zd-5DRLcq-nb9v27-hSShNW-4sk5S1-e7r1QM-5QNzVv-7sNicm-dN1TUs-6YWY3X-6YWWCv-gpVW66-6YWPbx-6YWTcc-QVvZh-jjzBWg-jahqpB-j2Y1XA-aRq6jg-5fmtnW-qKNC5-7Tn8wM-6FBfAK-akn7u2-4aMBK-628hS-i1CHCs-3dopVB-6293X-6293R-6293U-btgyyH-6YWX4Z-auKxW8-akpUGj">Billie Ward</a>.)</small>
