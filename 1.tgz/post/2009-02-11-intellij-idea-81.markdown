+++
date = "2009-02-11"
title = "IntelliJ IDEA 8.1"
categories = ["Java", "IntelliJ"]
+++
I do love IntelliJ IDEA  but the 8.0 release had some issues with indexing and compiler caches.
Version <a href="http://www.jetbrains.com/idea/features/newfeatures.html">8.1</a> is out  and addresses these issues (among other things, e.g. git support). Hurray.
