--- 
layout: post
title: Sorting your properties files in IntelliJ Idea
wordpress_id: "74"
wordpress_url: http://maxheapsize.com/?p=74
categories: IntelliJ Plugin 
comments: true
---
I do work with language property files pretty much every day (since I'm the GUI guy in the team). The files are updated on different branches copied up to the trunk and merged down to new branches, sometimes even updated by our product owner. We got a couple of times into not so funny merge conflicts since people did not sort the property files in the same way. To get around that we used an external tool to sort the files just before committing them. 

Right, we can do better than this. 

I wrote a small plugin for IntelliJ IDEA (and turns out my colleague too) for sorting these inside IDEA. I took the easy approach to sort them in the editor window. Simply open a properties file and choose <em>Code</em> - <em>Sort Properties</em>. It detects if this is  a real properties file (e.g. all lines do  have a # at the start or do follow the pattern key=value) and sorts them. If things go boom you always can undo ;-).

<img alt="" src="/static/ideapropertysorter_small.gif" title="Idea Property File Sorter" class="alignnone" width="300" height="240" />  

You can get it from <a href="/static/IdeaPropertySorter.zip">here</a>. It's just 7KB since I did not include the testng jars. 
